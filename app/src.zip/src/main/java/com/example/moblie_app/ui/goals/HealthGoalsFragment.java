package com.example.moblie_app.ui.goals;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.navigation.Navigation;

import com.example.moblie_app.R;
import com.example.moblie_app.model.HealthGoalsModel;
import com.example.moblie_app.viewmodel.HealthGoalsViewModel;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.chip.Chip;
import com.google.android.material.chip.ChipGroup;
import com.google.android.material.slider.Slider;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;

import java.util.Locale;

public class HealthGoalsFragment extends Fragment {

    private HealthGoalsViewModel viewModel;

    // Views
    private Slider            sliderWeight, sliderCalories, sliderSteps;
    private TextView          tvWeightBadge, tvCaloriesBadge, tvStepsBadge;
    private TextInputLayout   tilWeight, tilCalories, tilSteps;
    private TextInputEditText etWeight, etCalories, etSteps;
    private ChipGroup         chipGroupCalories, chipGroupSteps;
    private MaterialButton    btnSave, btnBack;
    private TextView          tvMessage;
    private ProgressBar       progressBar;

    // Flags để tránh vòng lặp listener
    private boolean isUpdatingFromSlider   = false;
    private boolean isUpdatingFromEditText = false;
    private boolean isUpdatingFromChip     = false;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_health_goals, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        bindViews(view);
        viewModel = new ViewModelProvider(this).get(HealthGoalsViewModel.class);

        setupSliderListeners();
        setupEditTextListeners();
        setupChipListeners();
        observeViewModel();

        btnBack.setOnClickListener(v ->
                Navigation.findNavController(v).popBackStack());

        btnSave.setOnClickListener(v -> {
            String w = etWeight.getText()   != null ? etWeight.getText().toString()   : "";
            String c = etCalories.getText() != null ? etCalories.getText().toString() : "";
            String s = etSteps.getText()    != null ? etSteps.getText().toString()    : "";
            viewModel.saveGoals(w, c, s);
        });

        viewModel.loadGoals();
    }

    // ----------------------------------------------------------------
    // Bind views
    // ----------------------------------------------------------------
    private void bindViews(View v) {
        sliderWeight     = v.findViewById(R.id.slider_weight);
        sliderCalories   = v.findViewById(R.id.slider_calories);
        sliderSteps      = v.findViewById(R.id.slider_steps);
        tvWeightBadge    = v.findViewById(R.id.tv_weight_badge);
        tvCaloriesBadge  = v.findViewById(R.id.tv_calories_badge);
        tvStepsBadge     = v.findViewById(R.id.tv_steps_badge);
        tilWeight        = v.findViewById(R.id.til_weight);
        tilCalories      = v.findViewById(R.id.til_calories);
        tilSteps         = v.findViewById(R.id.til_steps);
        etWeight         = v.findViewById(R.id.et_weight);
        etCalories       = v.findViewById(R.id.et_calories);
        etSteps          = v.findViewById(R.id.et_steps);
        chipGroupCalories = v.findViewById(R.id.chip_group_calories);
        chipGroupSteps   = v.findViewById(R.id.chip_group_steps);
        btnSave          = v.findViewById(R.id.btn_save);
        btnBack          = v.findViewById(R.id.btn_back);
        tvMessage        = v.findViewById(R.id.tv_message);
        progressBar      = v.findViewById(R.id.progress_bar);
    }

    // ----------------------------------------------------------------
    // Slider → Badge + EditText
    // ----------------------------------------------------------------
    private void setupSliderListeners() {
        sliderWeight.addOnChangeListener((slider, value, fromUser) -> {
            if (!fromUser) return;
            tvWeightBadge.setText(String.format(Locale.getDefault(), "%.1f kg", value));
            if (!isUpdatingFromEditText) {
                isUpdatingFromSlider = true;
                etWeight.setText(String.format(Locale.getDefault(), "%.1f", value));
                isUpdatingFromSlider = false;
            }
        });

        sliderCalories.addOnChangeListener((slider, value, fromUser) -> {
            if (!fromUser) return;
            int cal = (int) value;
            tvCaloriesBadge.setText(String.format(Locale.getDefault(), "%,d kcal", cal));
            if (!isUpdatingFromEditText) {
                isUpdatingFromSlider = true;
                etCalories.setText(String.valueOf(cal));
                isUpdatingFromSlider = false;
            }
            // Sync chip
            if (!isUpdatingFromChip) syncCaloriesChip(cal);
        });

        sliderSteps.addOnChangeListener((slider, value, fromUser) -> {
            if (!fromUser) return;
            int steps = (int) value;
            tvStepsBadge.setText(String.format(Locale.getDefault(), "%,d", steps));
            if (!isUpdatingFromEditText) {
                isUpdatingFromSlider = true;
                etSteps.setText(String.valueOf(steps));
                isUpdatingFromSlider = false;
            }
            if (!isUpdatingFromChip) syncStepsChip(steps);
        });
    }

    // ----------------------------------------------------------------
    // EditText → Slider + Badge
    // ----------------------------------------------------------------
    private void setupEditTextListeners() {
        etWeight.addTextChangedListener(new SimpleTextWatcher() {
            @Override public void afterTextChanged(Editable s) {
                if (isUpdatingFromSlider) return;
                try {
                    float v = Float.parseFloat(s.toString());
                    if (v >= 30 && v <= 150) {
                        isUpdatingFromEditText = true;
                        sliderWeight.setValue(v);
                        tvWeightBadge.setText(String.format(Locale.getDefault(), "%.1f kg", v));
                        isUpdatingFromEditText = false;
                        tilWeight.setError(null);
                    }
                } catch (NumberFormatException ignored) {}
            }
        });

        etCalories.addTextChangedListener(new SimpleTextWatcher() {
            @Override public void afterTextChanged(Editable s) {
                if (isUpdatingFromSlider) return;
                try {
                    int cal = Integer.parseInt(s.toString());
                    if (cal >= 800 && cal <= 4000) {
                        isUpdatingFromEditText = true;
                        sliderCalories.setValue(cal);
                        tvCaloriesBadge.setText(String.format(Locale.getDefault(), "%,d kcal", cal));
                        isUpdatingFromEditText = false;
                        syncCaloriesChip(cal);
                        tilCalories.setError(null);
                    }
                } catch (NumberFormatException ignored) {}
            }
        });

        etSteps.addTextChangedListener(new SimpleTextWatcher() {
            @Override public void afterTextChanged(Editable s) {
                if (isUpdatingFromSlider) return;
                try {
                    int steps = Integer.parseInt(s.toString());
                    if (steps >= 1000 && steps <= 30000) {
                        isUpdatingFromEditText = true;
                        sliderSteps.setValue(steps);
                        tvStepsBadge.setText(String.format(Locale.getDefault(), "%,d", steps));
                        isUpdatingFromEditText = false;
                        syncStepsChip(steps);
                        tilSteps.setError(null);
                    }
                } catch (NumberFormatException ignored) {}
            }
        });
    }

    // ----------------------------------------------------------------
    // Chip → Slider + EditText
    // ----------------------------------------------------------------
    private void setupChipListeners() {
        chipGroupCalories.setOnCheckedStateChangeListener((group, checkedIds) -> {
            if (checkedIds.isEmpty()) return;
            int cal = chipCalToValue(checkedIds.get(0));
            if (cal == -1) return;
            isUpdatingFromChip = true;
            sliderCalories.setValue(cal);
            etCalories.setText(String.valueOf(cal));
            tvCaloriesBadge.setText(String.format(Locale.getDefault(), "%,d kcal", cal));
            isUpdatingFromChip = false;
        });

        chipGroupSteps.setOnCheckedStateChangeListener((group, checkedIds) -> {
            if (checkedIds.isEmpty()) return;
            int steps = chipStepsToValue(checkedIds.get(0));
            if (steps == -1) return;
            isUpdatingFromChip = true;
            sliderSteps.setValue(steps);
            etSteps.setText(String.valueOf(steps));
            tvStepsBadge.setText(String.format(Locale.getDefault(), "%,d", steps));
            isUpdatingFromChip = false;
        });
    }

    // ----------------------------------------------------------------
    // Observe ViewModel
    // ----------------------------------------------------------------
    private void observeViewModel() {
        viewModel.getGoals().observe(getViewLifecycleOwner(), this::populateUI);

        viewModel.getIsLoading().observe(getViewLifecycleOwner(), loading -> {
            progressBar.setVisibility(loading ? View.VISIBLE : View.GONE);
            btnSave.setEnabled(!loading);
        });

        viewModel.getMessage().observe(getViewLifecycleOwner(), msg -> {
            if (msg == null || msg.isEmpty()) {
                tvMessage.setVisibility(View.GONE);
                return;
            }
            tvMessage.setVisibility(View.VISIBLE);
            tvMessage.setText(msg);
            // Màu đỏ nếu là lỗi, xanh nếu thành công/info
            boolean isError = msg.contains("không") || msg.contains("phải")
                           || msg.contains("hợp lệ");
            tvMessage.setTextColor(getResources().getColor(
                    isError ? R.color.health_error : R.color.health_green_medium,
                    null));
        });

        viewModel.getSaveSuccess().observe(getViewLifecycleOwner(), success -> {
            if (Boolean.TRUE.equals(success)) {
                tvMessage.setVisibility(View.VISIBLE);
                tvMessage.setText("✓ Đã lưu mục tiêu thành công");
                tvMessage.setTextColor(getResources().getColor(R.color.health_green_medium, null));
            }
        });
    }

    // ----------------------------------------------------------------
    // Populate UI từ model
    // ----------------------------------------------------------------
    private void populateUI(HealthGoalsModel model) {
        if (model == null) return;

        float weight = (float) model.getTargetWeight();
        int   cal    = model.getTargetCalories();
        int   steps  = model.getTargetSteps();

        // Weight
        sliderWeight.setValue(Math.max(30, Math.min(150, weight)));
        etWeight.setText(String.format(Locale.getDefault(), "%.1f", weight));
        tvWeightBadge.setText(String.format(Locale.getDefault(), "%.1f kg", weight));

        // Calories
        sliderCalories.setValue(Math.max(800, Math.min(4000, cal)));
        etCalories.setText(String.valueOf(cal));
        tvCaloriesBadge.setText(String.format(Locale.getDefault(), "%,d kcal", cal));
        syncCaloriesChip(cal);

        // Steps
        sliderSteps.setValue(Math.max(1000, Math.min(30000, steps)));
        etSteps.setText(String.valueOf(steps));
        tvStepsBadge.setText(String.format(Locale.getDefault(), "%,d", steps));
        syncStepsChip(steps);
    }

    // ----------------------------------------------------------------
    // Sync chip selection theo giá trị
    // ----------------------------------------------------------------
    private void syncCaloriesChip(int cal) {
        isUpdatingFromChip = true;
        int chipId = -1;
        if      (cal == 1200) chipId = R.id.chip_cal_1200;
        else if (cal == 1500) chipId = R.id.chip_cal_1500;
        else if (cal == 2000) chipId = R.id.chip_cal_2000;
        else if (cal == 2500) chipId = R.id.chip_cal_2500;
        else if (cal == 3000) chipId = R.id.chip_cal_3000;

        chipGroupCalories.clearCheck();
        if (chipId != -1) chipGroupCalories.check(chipId);
        isUpdatingFromChip = false;
    }

    private void syncStepsChip(int steps) {
        isUpdatingFromChip = true;
        int chipId = -1;
        if      (steps == 5000)  chipId = R.id.chip_steps_5000;
        else if (steps == 7000)  chipId = R.id.chip_steps_7000;
        else if (steps == 8000)  chipId = R.id.chip_steps_8000;
        else if (steps == 10000) chipId = R.id.chip_steps_10000;
        else if (steps == 15000) chipId = R.id.chip_steps_15000;

        chipGroupSteps.clearCheck();
        if (chipId != -1) chipGroupSteps.check(chipId);
        isUpdatingFromChip = false;
    }

    private int chipCalToValue(int chipId) {
        if      (chipId == R.id.chip_cal_1200) return 1200;
        else if (chipId == R.id.chip_cal_1500) return 1500;
        else if (chipId == R.id.chip_cal_2000) return 2000;
        else if (chipId == R.id.chip_cal_2500) return 2500;
        else if (chipId == R.id.chip_cal_3000) return 3000;
        return -1;
    }

    private int chipStepsToValue(int chipId) {
        if      (chipId == R.id.chip_steps_5000)  return 5000;
        else if (chipId == R.id.chip_steps_7000)  return 7000;
        else if (chipId == R.id.chip_steps_8000)  return 8000;
        else if (chipId == R.id.chip_steps_10000) return 10000;
        else if (chipId == R.id.chip_steps_15000) return 15000;
        return -1;
    }

    // ----------------------------------------------------------------
    // TextWatcher helper
    // ----------------------------------------------------------------
    private abstract static class SimpleTextWatcher implements TextWatcher {
        @Override public void beforeTextChanged(CharSequence s, int st, int c, int a) {}
        @Override public void onTextChanged(CharSequence s, int st, int b, int c)     {}
    }
}
